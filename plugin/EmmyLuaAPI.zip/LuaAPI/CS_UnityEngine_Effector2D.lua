---@class CS.UnityEngine.Effector2D : CS.UnityEngine.Behaviour
---@field public useColliderMask boolean
---@field public colliderMask number

---@type CS.UnityEngine.Effector2D
CS.UnityEngine.Effector2D = { }
---@return CS.UnityEngine.Effector2D
function CS.UnityEngine.Effector2D.New() end
return CS.UnityEngine.Effector2D
