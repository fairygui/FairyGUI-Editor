---@class CS.FairyEditor.Framework.Gears.FGearColor : CS.FairyEditor.Framework.Gears.FGearBase_CS.FairyEditor.Framework.Gears.FGearColorValue

---@type CS.FairyEditor.Framework.Gears.FGearColor
CS.FairyEditor.Framework.Gears.FGearColor = { }
---@return CS.FairyEditor.Framework.Gears.FGearColor
---@param owner CS.FairyEditor.FObject
function CS.FairyEditor.Framework.Gears.FGearColor.New(owner) end
function CS.FairyEditor.Framework.Gears.FGearColor:Apply() end
function CS.FairyEditor.Framework.Gears.FGearColor:UpdateState() end
return CS.FairyEditor.Framework.Gears.FGearColor
