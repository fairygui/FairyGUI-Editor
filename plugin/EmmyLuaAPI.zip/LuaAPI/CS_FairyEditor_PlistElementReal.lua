---@class CS.FairyEditor.PlistElementReal : CS.FairyEditor.PlistElement
---@field public value number

---@type CS.FairyEditor.PlistElementReal
CS.FairyEditor.PlistElementReal = { }
---@return CS.FairyEditor.PlistElementReal
---@param v number
function CS.FairyEditor.PlistElementReal.New(v) end
return CS.FairyEditor.PlistElementReal
