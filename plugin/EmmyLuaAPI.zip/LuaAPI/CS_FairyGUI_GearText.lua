---@class CS.FairyGUI.GearText : CS.FairyGUI.GearBase

---@type CS.FairyGUI.GearText
CS.FairyGUI.GearText = { }
---@return CS.FairyGUI.GearText
---@param owner CS.FairyGUI.GObject
function CS.FairyGUI.GearText.New(owner) end
function CS.FairyGUI.GearText:Apply() end
function CS.FairyGUI.GearText:UpdateState() end
return CS.FairyGUI.GearText
