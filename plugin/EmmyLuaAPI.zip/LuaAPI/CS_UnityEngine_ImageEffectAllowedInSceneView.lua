---@class CS.UnityEngine.ImageEffectAllowedInSceneView : CS.System.Attribute

---@type CS.UnityEngine.ImageEffectAllowedInSceneView
CS.UnityEngine.ImageEffectAllowedInSceneView = { }
---@return CS.UnityEngine.ImageEffectAllowedInSceneView
function CS.UnityEngine.ImageEffectAllowedInSceneView.New() end
return CS.UnityEngine.ImageEffectAllowedInSceneView
