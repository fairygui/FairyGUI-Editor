---@class CS.UnityEngine.StackTraceUtility

---@type CS.UnityEngine.StackTraceUtility
CS.UnityEngine.StackTraceUtility = { }
---@return string
function CS.UnityEngine.StackTraceUtility.ExtractStackTrace() end
---@return string
---@param exception CS.System.Object
function CS.UnityEngine.StackTraceUtility.ExtractStringFromException(exception) end
return CS.UnityEngine.StackTraceUtility
