---@class CS.FairyEditor.FEvents
---@field public POS_CHANGED string
---@field public SIZE_CHANGED string
---@field public CHANGED string
---@field public PLAY_END string
---@field public SUBMIT string
---@field public ADDED string
---@field public REMOVED string
---@field public CLICK_ITEM string

---@type CS.FairyEditor.FEvents
CS.FairyEditor.FEvents = { }
