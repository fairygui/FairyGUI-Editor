---@class CS.FairyEditor.View.HierarchyView : CS.FairyGUI.GComponent

---@type CS.FairyEditor.View.HierarchyView
CS.FairyEditor.View.HierarchyView = { }
---@return CS.FairyEditor.View.HierarchyView
function CS.FairyEditor.View.HierarchyView.New() end
return CS.FairyEditor.View.HierarchyView
