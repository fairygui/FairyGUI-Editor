---@class CS.FairyEditor.Framework.Gears.FGearSizeValue
---@field public width number
---@field public height number
---@field public scaleX number
---@field public scaleY number

---@type CS.FairyEditor.Framework.Gears.FGearSizeValue
CS.FairyEditor.Framework.Gears.FGearSizeValue = { }
---@return CS.FairyEditor.Framework.Gears.FGearSizeValue
function CS.FairyEditor.Framework.Gears.FGearSizeValue.New() end
return CS.FairyEditor.Framework.Gears.FGearSizeValue
