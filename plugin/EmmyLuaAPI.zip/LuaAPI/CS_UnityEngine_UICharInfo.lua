---@class CS.UnityEngine.UICharInfo : CS.System.ValueType
---@field public cursorPos CS.UnityEngine.Vector2
---@field public charWidth number

---@type CS.UnityEngine.UICharInfo
CS.UnityEngine.UICharInfo = { }
