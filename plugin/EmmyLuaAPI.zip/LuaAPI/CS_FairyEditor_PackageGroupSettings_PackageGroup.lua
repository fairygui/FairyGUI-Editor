---@class CS.FairyEditor.PackageGroupSettings.PackageGroup
---@field public name string
---@field public pkgs CS.System.Collections.Generic.List_CS.System.String

---@type CS.FairyEditor.PackageGroupSettings.PackageGroup
CS.FairyEditor.PackageGroupSettings.PackageGroup = { }
---@return CS.FairyEditor.PackageGroupSettings.PackageGroup
function CS.FairyEditor.PackageGroupSettings.PackageGroup.New() end
return CS.FairyEditor.PackageGroupSettings.PackageGroup
