---@class CS.UnityEngine.JointMotor2D : CS.System.ValueType
---@field public motorSpeed number
---@field public maxMotorTorque number

---@type CS.UnityEngine.JointMotor2D
CS.UnityEngine.JointMotor2D = { }
return CS.UnityEngine.JointMotor2D
