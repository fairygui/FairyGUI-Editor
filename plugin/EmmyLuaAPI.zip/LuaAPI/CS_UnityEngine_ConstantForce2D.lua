---@class CS.UnityEngine.ConstantForce2D : CS.UnityEngine.PhysicsUpdateBehaviour2D
---@field public force CS.UnityEngine.Vector2
---@field public relativeForce CS.UnityEngine.Vector2
---@field public torque number

---@type CS.UnityEngine.ConstantForce2D
CS.UnityEngine.ConstantForce2D = { }
---@return CS.UnityEngine.ConstantForce2D
function CS.UnityEngine.ConstantForce2D.New() end
return CS.UnityEngine.ConstantForce2D
