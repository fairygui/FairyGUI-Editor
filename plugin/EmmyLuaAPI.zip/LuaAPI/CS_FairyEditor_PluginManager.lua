---@class CS.FairyEditor.PluginManager
---@field public allPlugins CS.System.Collections.Generic.List_CS.FairyEditor.PluginManager.PluginInfo
---@field public userPluginFolder string
---@field public projectPluginFolder string

---@type CS.FairyEditor.PluginManager
CS.FairyEditor.PluginManager = { }
---@return CS.FairyEditor.PluginManager
function CS.FairyEditor.PluginManager.New() end
function CS.FairyEditor.PluginManager:Dispose() end
function CS.FairyEditor.PluginManager:Load() end
---@param filePath string
function CS.FairyEditor.PluginManager:LoadUIPackage(filePath) end
return CS.FairyEditor.PluginManager
