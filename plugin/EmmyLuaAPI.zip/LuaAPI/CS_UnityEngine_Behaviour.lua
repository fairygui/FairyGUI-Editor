---@class CS.UnityEngine.Behaviour : CS.UnityEngine.Component
---@field public enabled boolean
---@field public isActiveAndEnabled boolean

---@type CS.UnityEngine.Behaviour
CS.UnityEngine.Behaviour = { }
---@return CS.UnityEngine.Behaviour
function CS.UnityEngine.Behaviour.New() end
return CS.UnityEngine.Behaviour
