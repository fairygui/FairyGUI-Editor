---@class CS.FairyEditor.Bootstrap : CS.UnityEngine.MonoBehaviour

---@type CS.FairyEditor.Bootstrap
CS.FairyEditor.Bootstrap = { }
---@return CS.FairyEditor.Bootstrap
function CS.FairyEditor.Bootstrap.New() end
return CS.FairyEditor.Bootstrap
