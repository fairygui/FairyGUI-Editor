---@class CS.UnityEngine.SoftJointLimitSpring : CS.System.ValueType
---@field public spring number
---@field public damper number

---@type CS.UnityEngine.SoftJointLimitSpring
CS.UnityEngine.SoftJointLimitSpring = { }
return CS.UnityEngine.SoftJointLimitSpring
