---@class CS.FairyEditor.FontUtil

---@type CS.FairyEditor.FontUtil
CS.FairyEditor.FontUtil = { }
---@return FontInfo[]
---@param forceRefresh boolean
function CS.FairyEditor.FontUtil.GetOSInstalledFontNames(forceRefresh) end
---@return CS.FairyEditor.FontUtil.FontInfo
---@param fontFile string
function CS.FairyEditor.FontUtil.GetFontInfo(fontFile) end
---@return CS.FairyGUI.NTexture
---@param fontFile string
function CS.FairyEditor.FontUtil.GetPreviewTexture(fontFile) end
return CS.FairyEditor.FontUtil
