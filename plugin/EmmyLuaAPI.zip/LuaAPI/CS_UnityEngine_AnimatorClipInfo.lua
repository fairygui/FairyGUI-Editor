---@class CS.UnityEngine.AnimatorClipInfo : CS.System.ValueType
---@field public clip CS.UnityEngine.AnimationClip
---@field public weight number

---@type CS.UnityEngine.AnimatorClipInfo
CS.UnityEngine.AnimatorClipInfo = { }
return CS.UnityEngine.AnimatorClipInfo
