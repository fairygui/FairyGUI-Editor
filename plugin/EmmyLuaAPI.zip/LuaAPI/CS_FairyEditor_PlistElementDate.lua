---@class CS.FairyEditor.PlistElementDate : CS.FairyEditor.PlistElement
---@field public value CS.System.DateTime

---@type CS.FairyEditor.PlistElementDate
CS.FairyEditor.PlistElementDate = { }
---@return CS.FairyEditor.PlistElementDate
---@param date CS.System.DateTime
function CS.FairyEditor.PlistElementDate.New(date) end
return CS.FairyEditor.PlistElementDate
