---@class CS.FairyEditor.View.PreviewView : CS.FairyGUI.GComponent

---@type CS.FairyEditor.View.PreviewView
CS.FairyEditor.View.PreviewView = { }
---@return CS.FairyEditor.View.PreviewView
function CS.FairyEditor.View.PreviewView.New() end
---@param pi CS.FairyEditor.FPackageItem
function CS.FairyEditor.View.PreviewView:Show(pi) end
return CS.FairyEditor.View.PreviewView
