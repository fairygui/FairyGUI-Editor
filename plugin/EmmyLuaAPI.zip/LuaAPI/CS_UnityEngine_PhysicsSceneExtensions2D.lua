---@class CS.UnityEngine.PhysicsSceneExtensions2D

---@type CS.UnityEngine.PhysicsSceneExtensions2D
CS.UnityEngine.PhysicsSceneExtensions2D = { }
---@return CS.UnityEngine.PhysicsScene2D
function CS.UnityEngine.PhysicsSceneExtensions2D.GetPhysicsScene2D() end
return CS.UnityEngine.PhysicsSceneExtensions2D
