---@class CS.UnityEngine.AudioBehaviour : CS.UnityEngine.Behaviour

---@type CS.UnityEngine.AudioBehaviour
CS.UnityEngine.AudioBehaviour = { }
---@return CS.UnityEngine.AudioBehaviour
function CS.UnityEngine.AudioBehaviour.New() end
return CS.UnityEngine.AudioBehaviour
