---@class CS.UnityEngine.ResourceRequest : CS.UnityEngine.AsyncOperation
---@field public asset CS.UnityEngine.Object

---@type CS.UnityEngine.ResourceRequest
CS.UnityEngine.ResourceRequest = { }
---@return CS.UnityEngine.ResourceRequest
function CS.UnityEngine.ResourceRequest.New() end
return CS.UnityEngine.ResourceRequest
