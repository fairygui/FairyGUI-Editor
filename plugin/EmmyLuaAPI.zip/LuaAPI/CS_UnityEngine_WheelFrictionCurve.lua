---@class CS.UnityEngine.WheelFrictionCurve : CS.System.ValueType
---@field public extremumSlip number
---@field public extremumValue number
---@field public asymptoteSlip number
---@field public asymptoteValue number
---@field public stiffness number

---@type CS.UnityEngine.WheelFrictionCurve
CS.UnityEngine.WheelFrictionCurve = { }
return CS.UnityEngine.WheelFrictionCurve
