---@class CS.UnityEngine.OcclusionPortal : CS.UnityEngine.Component
---@field public open boolean

---@type CS.UnityEngine.OcclusionPortal
CS.UnityEngine.OcclusionPortal = { }
---@return CS.UnityEngine.OcclusionPortal
function CS.UnityEngine.OcclusionPortal.New() end
return CS.UnityEngine.OcclusionPortal
