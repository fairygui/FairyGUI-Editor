---@class CS.UnityEngine.HashUnsafeUtilities

---@type CS.UnityEngine.HashUnsafeUtilities
CS.UnityEngine.HashUnsafeUtilities = { }
---@overload fun(data:CS.System.Void*, dataSize:number, hash:CS.UnityEngine.Hash128*): void
---@param data CS.System.Void*
---@param dataSize number
---@param hash1 CS.System.UInt64*
---@param optional hash2 CS.System.UInt64*
function CS.UnityEngine.HashUnsafeUtilities.ComputeHash128(data, dataSize, hash1, hash2) end
return CS.UnityEngine.HashUnsafeUtilities
