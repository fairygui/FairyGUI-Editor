---@class CS.FairyGUI.DisplayObjectInfo : CS.UnityEngine.MonoBehaviour
---@field public displayObject CS.FairyGUI.DisplayObject

---@type CS.FairyGUI.DisplayObjectInfo
CS.FairyGUI.DisplayObjectInfo = { }
---@return CS.FairyGUI.DisplayObjectInfo
function CS.FairyGUI.DisplayObjectInfo.New() end
return CS.FairyGUI.DisplayObjectInfo
