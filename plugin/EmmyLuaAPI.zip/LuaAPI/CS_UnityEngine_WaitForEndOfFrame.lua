---@class CS.UnityEngine.WaitForEndOfFrame : CS.UnityEngine.YieldInstruction

---@type CS.UnityEngine.WaitForEndOfFrame
CS.UnityEngine.WaitForEndOfFrame = { }
---@return CS.UnityEngine.WaitForEndOfFrame
function CS.UnityEngine.WaitForEndOfFrame.New() end
return CS.UnityEngine.WaitForEndOfFrame
