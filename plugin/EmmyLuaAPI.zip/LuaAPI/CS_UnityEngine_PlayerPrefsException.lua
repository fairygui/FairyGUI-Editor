---@class CS.UnityEngine.PlayerPrefsException : CS.System.Exception

---@type CS.UnityEngine.PlayerPrefsException
CS.UnityEngine.PlayerPrefsException = { }
---@return CS.UnityEngine.PlayerPrefsException
---@param error string
function CS.UnityEngine.PlayerPrefsException.New(error) end
return CS.UnityEngine.PlayerPrefsException
