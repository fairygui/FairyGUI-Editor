---@class CS.UnityEngine.ClothSphereColliderPair : CS.System.ValueType
---@field public first CS.UnityEngine.SphereCollider
---@field public second CS.UnityEngine.SphereCollider

---@type CS.UnityEngine.ClothSphereColliderPair
CS.UnityEngine.ClothSphereColliderPair = { }
---@overload fun(a:CS.UnityEngine.SphereCollider): CS.UnityEngine.ClothSphereColliderPair
---@return CS.UnityEngine.ClothSphereColliderPair
---@param a CS.UnityEngine.SphereCollider
---@param optional b CS.UnityEngine.SphereCollider
function CS.UnityEngine.ClothSphereColliderPair.New(a, b) end
return CS.UnityEngine.ClothSphereColliderPair
