---@class CS.FairyGUI.BlurFilter
---@field public blurSize number
---@field public target CS.FairyGUI.DisplayObject

---@type CS.FairyGUI.BlurFilter
CS.FairyGUI.BlurFilter = { }
---@return CS.FairyGUI.BlurFilter
function CS.FairyGUI.BlurFilter.New() end
function CS.FairyGUI.BlurFilter:Dispose() end
function CS.FairyGUI.BlurFilter:Update() end
return CS.FairyGUI.BlurFilter
