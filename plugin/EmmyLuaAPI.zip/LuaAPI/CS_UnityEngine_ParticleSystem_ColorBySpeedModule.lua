---@class CS.UnityEngine.ParticleSystem.ColorBySpeedModule : CS.System.ValueType
---@field public enabled boolean
---@field public color CS.UnityEngine.ParticleSystem.MinMaxGradient
---@field public range CS.UnityEngine.Vector2

---@type CS.UnityEngine.ParticleSystem.ColorBySpeedModule
CS.UnityEngine.ParticleSystem.ColorBySpeedModule = { }
return CS.UnityEngine.ParticleSystem.ColorBySpeedModule
