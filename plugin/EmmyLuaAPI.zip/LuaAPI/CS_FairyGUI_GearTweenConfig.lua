---@class CS.FairyGUI.GearTweenConfig
---@field public tween boolean
---@field public easeType number
---@field public duration number
---@field public delay number

---@type CS.FairyGUI.GearTweenConfig
CS.FairyGUI.GearTweenConfig = { }
---@return CS.FairyGUI.GearTweenConfig
function CS.FairyGUI.GearTweenConfig.New() end
return CS.FairyGUI.GearTweenConfig
