---@class CS.UnityEngine.JointSuspension2D : CS.System.ValueType
---@field public dampingRatio number
---@field public frequency number
---@field public angle number

---@type CS.UnityEngine.JointSuspension2D
CS.UnityEngine.JointSuspension2D = { }
return CS.UnityEngine.JointSuspension2D
