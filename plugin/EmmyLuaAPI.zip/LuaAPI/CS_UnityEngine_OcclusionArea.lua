---@class CS.UnityEngine.OcclusionArea : CS.UnityEngine.Component
---@field public center CS.UnityEngine.Vector3
---@field public size CS.UnityEngine.Vector3

---@type CS.UnityEngine.OcclusionArea
CS.UnityEngine.OcclusionArea = { }
---@return CS.UnityEngine.OcclusionArea
function CS.UnityEngine.OcclusionArea.New() end
return CS.UnityEngine.OcclusionArea
