---@class CS.UnityEngine.RenderBuffer : CS.System.ValueType

---@type CS.UnityEngine.RenderBuffer
CS.UnityEngine.RenderBuffer = { }
---@return number
function CS.UnityEngine.RenderBuffer:GetNativeRenderBufferPtr() end
return CS.UnityEngine.RenderBuffer
