---@class CS.FairyGUI.BitmapFont.BMGlyph
---@field public x number
---@field public y number
---@field public width number
---@field public height number
---@field public advance number
---@field public lineHeight number
---@field public uv Vector2[]
---@field public channel number

---@type CS.FairyGUI.BitmapFont.BMGlyph
CS.FairyGUI.BitmapFont.BMGlyph = { }
---@return CS.FairyGUI.BitmapFont.BMGlyph
function CS.FairyGUI.BitmapFont.BMGlyph.New() end
return CS.FairyGUI.BitmapFont.BMGlyph
