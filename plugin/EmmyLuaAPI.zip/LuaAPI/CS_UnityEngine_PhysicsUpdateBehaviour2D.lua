---@class CS.UnityEngine.PhysicsUpdateBehaviour2D : CS.UnityEngine.Behaviour

---@type CS.UnityEngine.PhysicsUpdateBehaviour2D
CS.UnityEngine.PhysicsUpdateBehaviour2D = { }
---@return CS.UnityEngine.PhysicsUpdateBehaviour2D
function CS.UnityEngine.PhysicsUpdateBehaviour2D.New() end
return CS.UnityEngine.PhysicsUpdateBehaviour2D
