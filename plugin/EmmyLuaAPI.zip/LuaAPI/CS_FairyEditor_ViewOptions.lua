---@class CS.FairyEditor.ViewOptions
---@field public title string
---@field public icon string
---@field public hResizePriority number
---@field public vResizePriority number
---@field public location string

---@type CS.FairyEditor.ViewOptions
CS.FairyEditor.ViewOptions = { }
---@return CS.FairyEditor.ViewOptions
function CS.FairyEditor.ViewOptions.New() end
return CS.FairyEditor.ViewOptions
