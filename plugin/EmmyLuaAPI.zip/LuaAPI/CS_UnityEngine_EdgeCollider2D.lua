---@class CS.UnityEngine.EdgeCollider2D : CS.UnityEngine.Collider2D
---@field public edgeRadius number
---@field public edgeCount number
---@field public pointCount number
---@field public points Vector2[]

---@type CS.UnityEngine.EdgeCollider2D
CS.UnityEngine.EdgeCollider2D = { }
---@return CS.UnityEngine.EdgeCollider2D
function CS.UnityEngine.EdgeCollider2D.New() end
function CS.UnityEngine.EdgeCollider2D:Reset() end
return CS.UnityEngine.EdgeCollider2D
