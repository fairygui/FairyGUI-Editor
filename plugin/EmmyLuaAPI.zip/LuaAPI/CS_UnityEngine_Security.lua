---@class CS.UnityEngine.Security

---@type CS.UnityEngine.Security
CS.UnityEngine.Security = { }
---@return CS.UnityEngine.Security
function CS.UnityEngine.Security.New() end
return CS.UnityEngine.Security
