---@class CS.UnityEngine.ParticleSystem.ColorOverLifetimeModule : CS.System.ValueType
---@field public enabled boolean
---@field public color CS.UnityEngine.ParticleSystem.MinMaxGradient

---@type CS.UnityEngine.ParticleSystem.ColorOverLifetimeModule
CS.UnityEngine.ParticleSystem.ColorOverLifetimeModule = { }
return CS.UnityEngine.ParticleSystem.ColorOverLifetimeModule
