---@class CS.UnityEngine.ImageEffectAfterScale : CS.System.Attribute

---@type CS.UnityEngine.ImageEffectAfterScale
CS.UnityEngine.ImageEffectAfterScale = { }
---@return CS.UnityEngine.ImageEffectAfterScale
function CS.UnityEngine.ImageEffectAfterScale.New() end
return CS.UnityEngine.ImageEffectAfterScale
