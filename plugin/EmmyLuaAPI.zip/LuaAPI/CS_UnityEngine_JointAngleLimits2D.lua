---@class CS.UnityEngine.JointAngleLimits2D : CS.System.ValueType
---@field public min number
---@field public max number

---@type CS.UnityEngine.JointAngleLimits2D
CS.UnityEngine.JointAngleLimits2D = { }
return CS.UnityEngine.JointAngleLimits2D
