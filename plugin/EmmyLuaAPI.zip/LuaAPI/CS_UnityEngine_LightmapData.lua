---@class CS.UnityEngine.LightmapData
---@field public lightmapColor CS.UnityEngine.Texture2D
---@field public lightmapDir CS.UnityEngine.Texture2D
---@field public shadowMask CS.UnityEngine.Texture2D

---@type CS.UnityEngine.LightmapData
CS.UnityEngine.LightmapData = { }
---@return CS.UnityEngine.LightmapData
function CS.UnityEngine.LightmapData.New() end
return CS.UnityEngine.LightmapData
