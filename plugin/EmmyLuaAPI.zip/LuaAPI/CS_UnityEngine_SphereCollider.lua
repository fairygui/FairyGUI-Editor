---@class CS.UnityEngine.SphereCollider : CS.UnityEngine.Collider
---@field public center CS.UnityEngine.Vector3
---@field public radius number

---@type CS.UnityEngine.SphereCollider
CS.UnityEngine.SphereCollider = { }
---@return CS.UnityEngine.SphereCollider
function CS.UnityEngine.SphereCollider.New() end
return CS.UnityEngine.SphereCollider
