---@class CS.UnityEngine.JointSpring : CS.System.ValueType
---@field public spring number
---@field public damper number
---@field public targetPosition number

---@type CS.UnityEngine.JointSpring
CS.UnityEngine.JointSpring = { }
