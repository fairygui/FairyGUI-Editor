---@class CS.UnityEngine.RendererExtensions

---@type CS.UnityEngine.RendererExtensions
CS.UnityEngine.RendererExtensions = { }
function CS.UnityEngine.RendererExtensions.UpdateGIMaterials() end
return CS.UnityEngine.RendererExtensions
