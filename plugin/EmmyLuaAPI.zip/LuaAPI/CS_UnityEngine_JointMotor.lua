---@class CS.UnityEngine.JointMotor : CS.System.ValueType
---@field public targetVelocity number
---@field public force number
---@field public freeSpin boolean

---@type CS.UnityEngine.JointMotor
CS.UnityEngine.JointMotor = { }
return CS.UnityEngine.JointMotor
