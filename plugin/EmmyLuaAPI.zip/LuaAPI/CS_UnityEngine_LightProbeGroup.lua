---@class CS.UnityEngine.LightProbeGroup : CS.UnityEngine.Behaviour
---@field public probePositions Vector3[]
---@field public dering boolean

---@type CS.UnityEngine.LightProbeGroup
CS.UnityEngine.LightProbeGroup = { }
---@return CS.UnityEngine.LightProbeGroup
function CS.UnityEngine.LightProbeGroup.New() end
return CS.UnityEngine.LightProbeGroup
