---@class CS.FairyEditor.AniData.Frame
---@field public rect CS.UnityEngine.Rect
---@field public spriteIndex number
---@field public delay number

---@type CS.FairyEditor.AniData.Frame
CS.FairyEditor.AniData.Frame = { }
---@return CS.FairyEditor.AniData.Frame
function CS.FairyEditor.AniData.Frame.New() end
return CS.FairyEditor.AniData.Frame
