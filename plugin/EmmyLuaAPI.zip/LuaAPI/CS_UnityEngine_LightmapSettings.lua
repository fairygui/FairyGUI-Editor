---@class CS.UnityEngine.LightmapSettings : CS.UnityEngine.Object
---@field public lightmaps LightmapData[]
---@field public lightmapsMode number
---@field public lightProbes CS.UnityEngine.LightProbes

---@type CS.UnityEngine.LightmapSettings
CS.UnityEngine.LightmapSettings = { }
return CS.UnityEngine.LightmapSettings
