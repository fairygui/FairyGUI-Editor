---@class CS.FairyEditor.OverflowConst
---@field public VISIBLE string
---@field public HIDDEN string
---@field public SCROLL string

---@type CS.FairyEditor.OverflowConst
CS.FairyEditor.OverflowConst = { }
