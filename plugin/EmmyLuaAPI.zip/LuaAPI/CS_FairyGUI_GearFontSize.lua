---@class CS.FairyGUI.GearFontSize : CS.FairyGUI.GearBase

---@type CS.FairyGUI.GearFontSize
CS.FairyGUI.GearFontSize = { }
---@return CS.FairyGUI.GearFontSize
---@param owner CS.FairyGUI.GObject
function CS.FairyGUI.GearFontSize.New(owner) end
function CS.FairyGUI.GearFontSize:Apply() end
function CS.FairyGUI.GearFontSize:UpdateState() end
return CS.FairyGUI.GearFontSize
