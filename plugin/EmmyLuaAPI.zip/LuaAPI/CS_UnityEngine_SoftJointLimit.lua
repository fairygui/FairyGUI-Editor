---@class CS.UnityEngine.SoftJointLimit : CS.System.ValueType
---@field public limit number
---@field public bounciness number
---@field public contactDistance number

---@type CS.UnityEngine.SoftJointLimit
CS.UnityEngine.SoftJointLimit = { }
return CS.UnityEngine.SoftJointLimit
