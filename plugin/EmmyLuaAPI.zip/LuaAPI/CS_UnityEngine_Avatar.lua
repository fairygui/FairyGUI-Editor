---@class CS.UnityEngine.Avatar : CS.UnityEngine.Object
---@field public isValid boolean
---@field public isHuman boolean

---@type CS.UnityEngine.Avatar
CS.UnityEngine.Avatar = { }
return CS.UnityEngine.Avatar
