---@class CS.UnityEngine.ScriptableObject : CS.UnityEngine.Object

---@type CS.UnityEngine.ScriptableObject
CS.UnityEngine.ScriptableObject = { }
---@return CS.UnityEngine.ScriptableObject
function CS.UnityEngine.ScriptableObject.New() end
---@return CS.UnityEngine.ScriptableObject
---@param t string
function CS.UnityEngine.ScriptableObject.CreateInstance(t) end
return CS.UnityEngine.ScriptableObject
