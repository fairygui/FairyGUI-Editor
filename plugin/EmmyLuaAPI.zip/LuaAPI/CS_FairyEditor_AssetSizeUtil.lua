---@class CS.FairyEditor.AssetSizeUtil

---@type CS.FairyEditor.AssetSizeUtil
CS.FairyEditor.AssetSizeUtil = { }
---@return CS.FairyEditor.AssetSizeUtil.Result
---@param file string
function CS.FairyEditor.AssetSizeUtil.GetSize(file) end
return CS.FairyEditor.AssetSizeUtil
