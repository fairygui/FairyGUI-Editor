---@class CS.FairyEditor.ComExtensionDef
---@field public name string
---@field public className string
---@field public superClassName string

---@type CS.FairyEditor.ComExtensionDef
CS.FairyEditor.ComExtensionDef = { }
---@return CS.FairyEditor.ComExtensionDef
function CS.FairyEditor.ComExtensionDef.New() end
return CS.FairyEditor.ComExtensionDef
