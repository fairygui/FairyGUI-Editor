---@class CS.FairyGUI.GRichTextField : CS.FairyGUI.GTextField
---@field public richTextField CS.FairyGUI.RichTextField
---@field public emojies CS.System.Collections.Generic.Dictionary_CS.System.UInt32_CS.FairyGUI.Emoji

---@type CS.FairyGUI.GRichTextField
CS.FairyGUI.GRichTextField = { }
---@return CS.FairyGUI.GRichTextField
function CS.FairyGUI.GRichTextField.New() end
return CS.FairyGUI.GRichTextField
