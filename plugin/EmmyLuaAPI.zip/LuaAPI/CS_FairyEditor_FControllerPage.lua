---@class CS.FairyEditor.FControllerPage
---@field public id string
---@field public name string
---@field public remark string

---@type CS.FairyEditor.FControllerPage
CS.FairyEditor.FControllerPage = { }
---@return CS.FairyEditor.FControllerPage
function CS.FairyEditor.FControllerPage.New() end
return CS.FairyEditor.FControllerPage
