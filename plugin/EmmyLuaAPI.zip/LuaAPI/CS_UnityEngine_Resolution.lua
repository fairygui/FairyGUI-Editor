---@class CS.UnityEngine.Resolution : CS.System.ValueType
---@field public width number
---@field public height number
---@field public refreshRate number

---@type CS.UnityEngine.Resolution
CS.UnityEngine.Resolution = { }
---@return string
function CS.UnityEngine.Resolution:ToString() end
return CS.UnityEngine.Resolution
