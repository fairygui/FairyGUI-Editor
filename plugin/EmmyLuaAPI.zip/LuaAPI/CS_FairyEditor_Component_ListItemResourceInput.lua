---@class CS.FairyEditor.Component.ListItemResourceInput : CS.FairyEditor.Component.ResourceInput
---@field public toggleClickCount number

---@type CS.FairyEditor.Component.ListItemResourceInput
CS.FairyEditor.Component.ListItemResourceInput = { }
---@return CS.FairyEditor.Component.ListItemResourceInput
function CS.FairyEditor.Component.ListItemResourceInput.New() end
function CS.FairyEditor.Component.ListItemResourceInput:StartEditing() end
return CS.FairyEditor.Component.ListItemResourceInput
