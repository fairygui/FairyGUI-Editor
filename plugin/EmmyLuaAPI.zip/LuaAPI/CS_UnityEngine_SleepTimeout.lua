---@class CS.UnityEngine.SleepTimeout
---@field public NeverSleep number
---@field public SystemSetting number

---@type CS.UnityEngine.SleepTimeout
CS.UnityEngine.SleepTimeout = { }
---@return CS.UnityEngine.SleepTimeout
function CS.UnityEngine.SleepTimeout.New() end
return CS.UnityEngine.SleepTimeout
