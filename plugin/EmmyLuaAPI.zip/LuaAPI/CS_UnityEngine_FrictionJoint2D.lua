---@class CS.UnityEngine.FrictionJoint2D : CS.UnityEngine.AnchoredJoint2D
---@field public maxForce number
---@field public maxTorque number

---@type CS.UnityEngine.FrictionJoint2D
CS.UnityEngine.FrictionJoint2D = { }
---@return CS.UnityEngine.FrictionJoint2D
function CS.UnityEngine.FrictionJoint2D.New() end
return CS.UnityEngine.FrictionJoint2D
