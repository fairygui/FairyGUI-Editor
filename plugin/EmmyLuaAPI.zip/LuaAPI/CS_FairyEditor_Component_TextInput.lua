---@class CS.FairyEditor.Component.TextInput : CS.FairyGUI.GLabel
---@field public text string

---@type CS.FairyEditor.Component.TextInput
CS.FairyEditor.Component.TextInput = { }
---@return CS.FairyEditor.Component.TextInput
function CS.FairyEditor.Component.TextInput.New() end
---@param xml CS.FairyGUI.Utils.XML
function CS.FairyEditor.Component.TextInput:ConstructFromXML(xml) end
return CS.FairyEditor.Component.TextInput
