---@class CS.UnityEngine.JointDrive : CS.System.ValueType
---@field public positionSpring number
---@field public positionDamper number
---@field public maximumForce number

---@type CS.UnityEngine.JointDrive
CS.UnityEngine.JointDrive = { }
return CS.UnityEngine.JointDrive
