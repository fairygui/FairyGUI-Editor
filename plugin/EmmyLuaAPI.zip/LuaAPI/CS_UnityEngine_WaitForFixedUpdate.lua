---@class CS.UnityEngine.WaitForFixedUpdate : CS.UnityEngine.YieldInstruction

---@type CS.UnityEngine.WaitForFixedUpdate
CS.UnityEngine.WaitForFixedUpdate = { }
---@return CS.UnityEngine.WaitForFixedUpdate
function CS.UnityEngine.WaitForFixedUpdate.New() end
return CS.UnityEngine.WaitForFixedUpdate
