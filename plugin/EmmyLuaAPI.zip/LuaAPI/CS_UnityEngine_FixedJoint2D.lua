---@class CS.UnityEngine.FixedJoint2D : CS.UnityEngine.AnchoredJoint2D
---@field public dampingRatio number
---@field public frequency number
---@field public referenceAngle number

---@type CS.UnityEngine.FixedJoint2D
CS.UnityEngine.FixedJoint2D = { }
---@return CS.UnityEngine.FixedJoint2D
function CS.UnityEngine.FixedJoint2D.New() end
return CS.UnityEngine.FixedJoint2D
