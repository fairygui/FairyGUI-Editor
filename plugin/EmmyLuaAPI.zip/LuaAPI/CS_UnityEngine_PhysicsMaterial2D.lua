---@class CS.UnityEngine.PhysicsMaterial2D : CS.UnityEngine.Object
---@field public bounciness number
---@field public friction number

---@type CS.UnityEngine.PhysicsMaterial2D
CS.UnityEngine.PhysicsMaterial2D = { }
---@overload fun(): CS.UnityEngine.PhysicsMaterial2D
---@return CS.UnityEngine.PhysicsMaterial2D
---@param optional name string
function CS.UnityEngine.PhysicsMaterial2D.New(name) end
return CS.UnityEngine.PhysicsMaterial2D
