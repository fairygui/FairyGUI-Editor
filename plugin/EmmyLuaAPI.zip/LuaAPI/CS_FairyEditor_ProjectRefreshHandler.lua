---@class CS.FairyEditor.ProjectRefreshHandler

---@type CS.FairyEditor.ProjectRefreshHandler
CS.FairyEditor.ProjectRefreshHandler = { }
---@return CS.FairyEditor.ProjectRefreshHandler
function CS.FairyEditor.ProjectRefreshHandler.New() end
function CS.FairyEditor.ProjectRefreshHandler:Dispose() end
function CS.FairyEditor.ProjectRefreshHandler:Run() end
return CS.FairyEditor.ProjectRefreshHandler
