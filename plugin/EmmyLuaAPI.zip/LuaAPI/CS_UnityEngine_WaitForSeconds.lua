---@class CS.UnityEngine.WaitForSeconds : CS.UnityEngine.YieldInstruction

---@type CS.UnityEngine.WaitForSeconds
CS.UnityEngine.WaitForSeconds = { }
---@return CS.UnityEngine.WaitForSeconds
---@param seconds number
function CS.UnityEngine.WaitForSeconds.New(seconds) end
return CS.UnityEngine.WaitForSeconds
