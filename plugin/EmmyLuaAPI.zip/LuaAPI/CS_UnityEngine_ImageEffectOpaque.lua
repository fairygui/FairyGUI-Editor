---@class CS.UnityEngine.ImageEffectOpaque : CS.System.Attribute

---@type CS.UnityEngine.ImageEffectOpaque
CS.UnityEngine.ImageEffectOpaque = { }
---@return CS.UnityEngine.ImageEffectOpaque
function CS.UnityEngine.ImageEffectOpaque.New() end
return CS.UnityEngine.ImageEffectOpaque
