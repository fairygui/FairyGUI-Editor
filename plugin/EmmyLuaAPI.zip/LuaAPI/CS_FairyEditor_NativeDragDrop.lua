---@class CS.FairyEditor.NativeDragDrop

---@type CS.FairyEditor.NativeDragDrop
CS.FairyEditor.NativeDragDrop = { }
function CS.FairyEditor.NativeDragDrop.Init() end
function CS.FairyEditor.NativeDragDrop.Dispose() end
return CS.FairyEditor.NativeDragDrop
