---@class CS.UnityEngine.YieldInstruction

---@type CS.UnityEngine.YieldInstruction
CS.UnityEngine.YieldInstruction = { }
---@return CS.UnityEngine.YieldInstruction
function CS.UnityEngine.YieldInstruction.New() end
return CS.UnityEngine.YieldInstruction
